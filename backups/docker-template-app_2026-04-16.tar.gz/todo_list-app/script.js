let tasks = [];
let filter = 'all';

function load() {
  try {
    tasks = JSON.parse(localStorage.getItem('tasks_v1') || '[]');
  } catch (e) {
    tasks = [];
  }
  render();
}

function save() {
  localStorage.setItem('tasks_v1', JSON.stringify(tasks));
}

function addTask() {
  const input = document.getElementById('task-input');
  const text = input.value.trim();
  if (!text) {
    input.focus();
    return;
  }
  tasks.unshift({
    id: Date.now(),
    text,
    done: false,
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  });
  input.value = '';
  save();
  render();
  input.focus();
}

function toggleTask(id) {
  tasks = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
  save();
  render();
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  save();
  render();
}

function clearCompleted() {
  tasks = tasks.filter(t => !t.done);
  save();
  render();
}

function setFilter(f, el) {
  filter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  render();
}

function escHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function render() {
  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  const active = total - done;

  document.getElementById('stats').textContent =
    total === 0 ? '' : `${active} remaining · ${done} completed`;

  const visible = tasks.filter(t => {
    if (filter === 'active') return !t.done;
    if (filter === 'done') return t.done;
    return true;
  });

  const list = document.getElementById('task-list');

  if (visible.length === 0) {
    const msgs = {
      all: 'No tasks yet — add one above!',
      active: 'No active tasks.',
      done: 'Nothing completed yet.'
    };
    list.innerHTML = `<div class="empty">${msgs[filter]}</div>`;
    return;
  }

  list.innerHTML = visible.map(t => `
    <div class="task-item ${t.done ? 'done' : ''}">
      <div class="task-check ${t.done ? 'checked' : ''}" onclick="toggleTask(${t.id})">
        <svg class="checkmark" width="10" height="8" viewBox="0 0 10 8" fill="none">
          <path d="M1 4L3.5 6.5L9 1" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <span class="task-text">${escHtml(t.text)}</span>
      <span class="task-date">${t.date || ''}</span>
      <button class="delete-btn" onclick="deleteTask(${t.id})" title="Delete task">&#x2715;</button>
    </div>
  `).join('');
}

document.getElementById('task-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') addTask();
});

load();
