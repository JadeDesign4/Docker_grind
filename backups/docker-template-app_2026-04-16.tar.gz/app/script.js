// ── State ────────────────────────────────────────────────────────────────────
const MODES = { pomodoro: 25, short: 5, long: 15 };
const LABELS = { pomodoro: 'Focus time', short: 'Short break', long: 'Long break' };
const RING_TOTAL = 753.98;

let durations   = { ...MODES };          // minutes (editable)
let mode        = 'pomodoro';
let totalSecs   = durations.pomodoro * 60;
let remaining   = totalSecs;
let running     = false;
let interval    = null;
let sessionNum  = 1;
let completed   = 0;
let minutesFocused = 0;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const display   = document.getElementById('time-display');
const ring      = document.getElementById('ring');
const startBtn  = document.getElementById('start-btn');
const modeLabel = document.getElementById('mode-label');
const sesNum    = document.getElementById('session-num');
const statComp  = document.getElementById('stat-completed');
const statMin   = document.getElementById('stat-minutes');
const appEl     = document.querySelector('.app');

// ── SVG gradient inject ───────────────────────────────────────────────────────
(function injectGradient() {
  const svg = document.querySelector('.ring-svg');
  const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
  defs.innerHTML = `
    <linearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%"   stop-color="#FBBF24"/>
      <stop offset="100%" stop-color="#E8390E"/>
    </linearGradient>`;
  svg.prepend(defs);
})();

// ── Load from localStorage ────────────────────────────────────────────────────
function loadStats() {
  const saved = JSON.parse(localStorage.getItem('pomodoro_stats') || '{}');
  completed      = saved.completed || 0;
  minutesFocused = saved.minutesFocused || 0;
  sessionNum     = saved.sessionNum || 1;
  updateStatsUI();
}

function saveStats() {
  localStorage.setItem('pomodoro_stats', JSON.stringify({ completed, minutesFocused, sessionNum }));
}

function updateStatsUI() {
  statComp.textContent = completed;
  statMin.textContent  = minutesFocused;
  sesNum.textContent   = sessionNum;
}

// ── Timer logic ───────────────────────────────────────────────────────────────
function toggleTimer() {
  running ? pauseTimer() : startTimer();
}

function startTimer() {
  running = true;
  startBtn.textContent = 'Pause';
  appEl.classList.add('running');
  interval = setInterval(tick, 1000);
}

function pauseTimer() {
  running = false;
  startBtn.textContent = 'Resume';
  appEl.classList.remove('running');
  clearInterval(interval);
}

function resetTimer() {
  pauseTimer();
  startBtn.textContent = 'Start';
  remaining = totalSecs;
  updateDisplay();
  updateRing();
}

function tick() {
  if (remaining <= 0) {
    onSessionEnd();
    return;
  }
  remaining--;
  updateDisplay();
  updateRing();
}

function onSessionEnd() {
  clearInterval(interval);
  running = false;
  appEl.classList.remove('running');
  startBtn.textContent = 'Start';

  playSound();

  if (mode === 'pomodoro') {
    completed++;
    minutesFocused += durations.pomodoro;
    sessionNum++;
    saveStats();
    updateStatsUI();
    alert('🍅 Pomodoro complete! Time for a break.');
    switchMode(completed % 4 === 0 ? 'long' : 'short',
      document.querySelector(`.tab[data-mode="${completed % 4 === 0 ? 'long' : 'short'}"]`));
  } else {
    alert('Break over! Back to focus. 💪');
    switchMode('pomodoro', document.querySelector('.tab[data-mode="pomodoro"]'));
  }
}

function skipSession() {
  onSessionEnd();
}

// ── Display ───────────────────────────────────────────────────────────────────
function updateDisplay() {
  const m = Math.floor(remaining / 60).toString().padStart(2, '0');
  const s = (remaining % 60).toString().padStart(2, '0');
  display.textContent = `${m}:${s}`;
  document.title = `${m}:${s} — Pomodo`;
}

function updateRing() {
  const progress = remaining / totalSecs;
  const offset   = RING_TOTAL * (1 - progress);
  ring.style.strokeDashoffset = offset;
}

// ── Mode switching ────────────────────────────────────────────────────────────
function switchMode(m, el) {
  pauseTimer();
  startBtn.textContent = 'Start';
  mode      = m;
  totalSecs = durations[m] * 60;
  remaining = totalSecs;

  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  if (el) el.classList.add('active');

  modeLabel.textContent = LABELS[m];
  updateDisplay();
  updateRing();
}

// ── Custom durations ──────────────────────────────────────────────────────────
function updateDurations() {
  durations.pomodoro = parseInt(document.getElementById('set-pomodoro').value) || 25;
  durations.short    = parseInt(document.getElementById('set-short').value)    || 5;
  durations.long     = parseInt(document.getElementById('set-long').value)     || 15;
  switchMode(mode, document.querySelector(`.tab[data-mode="${mode}"]`));
}

// ── Sound alert (Web Audio API) ───────────────────────────────────────────────
function playSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [523, 659, 784, 1047]; // C5 E5 G5 C6
    notes.forEach((freq, i) => {
      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.value = freq;
      const t = ctx.currentTime + i * 0.18;
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.4, t + 0.05);
      gain.gain.linearRampToValueAtTime(0, t + 0.35);
      osc.start(t);
      osc.stop(t + 0.4);
    });
  } catch (e) {
    console.warn('Audio not available:', e);
  }
}

// ── Init ──────────────────────────────────────────────────────────────────────
loadStats();
updateDisplay();
updateRing();
