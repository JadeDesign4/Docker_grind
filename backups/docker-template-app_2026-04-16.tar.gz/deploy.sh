echo "🚀 JADE DESIGN DEPLOYMENT...."
#Variables
PORTA=9000
PORTB=9100
PORTC=9200

# 1. Check if YAML file exist
if [ -f "docker-compose.yml" ]; then
	echo "✅ YAML found. Proceeding...."
else
	echo "❌ ERROR: docker-compose.yml Missing!"
fi
sleep 1
echo ""

# 2. Clean up old containers
echo "🧹 Cleaning up old containers...."
docker compose down
sleep 1
echo ""

# 3. Smart Port Check
if ss -tulpn | grep -Eq ":$PORTA|:$PORTB|:$PORTC"; then
	echo "⚠️ WARNING! Ports $PORT1, $PORT2 && $PORT3 are already in use by another service."
	sleep 3
	echo "🔎 Checking what service is running there...."
	ss -tulpn | grep -E "$PORA|$PORTB|$PORTC"
	echo "❌ Please! stop the conflicting service or change the PORT in the 'docker-compose.yml' file"
	exit 1
else
	echo "✅ Ports $PORTA, $PORTB, $PORTC are available. Ready for Takeoff.... 🚀"
fi
sleep 2
echo ""

# 4. Backup files
echo "💾 Backing up files...."
tar -czf ~/me/cloud/Docker_grind/backups/docker-template-app_$(date +%F).tar.gz .
sleep 2
echo ""

# 5. Start the service
echo "📦 Starting up the service...."
docker compose up -d

echo "======================================================================================="
echo "::✨Deployment Complete::"
echo "View Your sites at http://localhost:9000, http://localhost:9100 & http://localhost:9200"
echo "======================================================================================="
